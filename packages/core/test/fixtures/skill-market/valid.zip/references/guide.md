Review changed code and report actionable findings.
